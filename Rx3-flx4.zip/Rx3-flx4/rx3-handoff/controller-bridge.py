#!/usr/bin/env python3
"""DJ controller -> XDJ-RX3 firmware control bridge (DDJ-FLX4, DDJ-400; see controllers.py).

Reads raw MIDI from the controller and translates it into the RX3 firmware's
queued key messages on the chroot control FIFO (see control-shim.c):
  struct command {int key,operation,channel,value; float analog; int extra;}
  operation: 0 press, 2 release, 4 rotary/analog, 5 switch/tempo.  channel: 0 global, 1 deck1, 2 deck2.

MIDI map is the DDJ-400 family layout (documented by Pioneer, cross-checked against Mixxx's mappings):
  note-on/off on ch0/ch1 = deck 1/2 buttons, ch6 = mixer/browse buttons, ch4/5 = Beat FX,
  ch7/ch9 = deck 1/2 pads (ch8/10 with SHIFT), CC on ch0/ch1 = deck knobs/faders, ch6 = master.
Usage: controller-bridge.py [/dev/snd/midiC?D0]   (auto-detects the first connected known controller)
       RX3_CONTROLLER=flx4|ddj400 forces the controller profile; a device of "-" reads MIDI from stdin and writes
       outgoing MIDI (LEDs, keep-alive) to $RX3_MIDI_OUT, for testing a mapping without the hardware.
"""
import glob, os, struct, sys, time, threading

import rx3_env, controllers
ROOT = rx3_env.ROOT
FIFO = ROOT + '/dev/rx3-control'

# ---- RX3 firmware key ids (keycodes.txt) ----
K = dict(play=0x4101, cue=0x4102, shift=0x4103, vinyl=0x4104, temporange=0x4107, mastertempo=0x4108,
         tempo=0x4109, quantize=0x410b, loopin=0x410c, loopout=0x410d, reloop=0x410e, slip=0x4110,
         master=0x4111, sync=0x4112, hotcue=0x4113, autobeatloop=0x4114, beatjump=0x4116,
         searchfwd=0x411f, searchrev=0x4120, rotary=0x420c, back=0x420d, trackfwd=0x4214, trackrev=0x4215,
         jog=0x4305, jogtouch=0x4306, load=0x4311, masterlv=0x4403, hpmix=0x4405, hplv=0x4406,
         fxonoff=0x448d, fxtime=0x448e, fxdepth=0x448f, beatprev=0x4490, beatnext=0x4491, fxselect=0x448b, fxch=0x448c, tap=0x4492,
         callnext=0x4322, callprev=0x4323,
         trim=0x5019, eqh=0x501a, eqm=0x501b, eql=0x501c, fader=0x501e, hpcue=0x5020, color=0x509d,
         cfxfilter=0x50a6, cfxspace=0x50a1, cfxdubecho=0x50a2, cfxcrush=0x50a5, cfxknob=0x50a7, cross=0x6017,
         source=0x0201, browse=0x0202, taglist=0x0203, playlist=0x0204, search=0x0205, menu=0x0206, usb1=0x209, usbstop=0x8002,
         tagtrack=0x420e, trackfilter=0x420f, shortcut=0x0210, linkcue=0x4408, time=0x410a)
PAD = [0x4117 + i for i in range(8)]

fifo = os.open(FIFO, os.O_RDWR | os.O_NONBLOCK)
LOG = os.environ.get('RX3_BRIDGE_LOG')
def send(key, op, ch=0, value=0, analog=0.0, extra=0):
    if LOG: print('%s key=%04x op=%d ch=%d val=%d a=%.3f ex=%d' % (time.strftime('%H:%M:%S'), key, op, ch, value, analog, extra), flush=True)
    try: os.write(fifo, struct.pack('<iiiifi', key, op, ch, value, analog, extra))
    except BlockingIOError: pass
def press(key, ch, down): send(key, 0 if down else 2, ch)
def analog(key, ch, v): send(key, 4, ch, 0, v)

# ---- is the firmware showing its deck (play) screen? ----
# The deck screen always has the same white labels in its two bottom panels ("TRACK", "TEMPO" for each deck),
# whether or not tracks are loaded or playing, and with the INFO panel open. Measured on firmware 1.19: 75, 75,
# 128, 128 lit pixels in these boxes; the library, source and shortcut screens have nothing like it. Reading the
# firmware's own 1280x800 picture is self-correcting, unlike tracking screen changes we cannot all see.
FW_FB = ROOT + '/dev/fb0'
DECK_LABELS = (((36, 648, 80, 661), 75), ((676, 648, 720, 661), 75), ((396, 648, 441, 661), 128), ((1036, 648, 1081, 661), 128))
def deck_showing():
    try: fd = os.open(FW_FB, os.O_RDONLY)
    except OSError: return False
    try:
        for (x0, y0, x1, y1), expect in DECK_LABELS:
            lit = 0
            for y in range(y0, y1):
                row = os.pread(fd, (x1 - x0) * 4, (y * 1280 + x0) * 4)   # BGRX
                lit += sum(1 for k in range(0, len(row) - 3, 4) if row[k] > 170 and row[k + 1] > 170 and row[k + 2] > 170)
            if abs(lit - expect) > expect // 4: return False
        return True
    finally: os.close(fd)

def track_selected():
    """Is a playable track currently highlighted in the library (has LOAD 1 / LOAD 2 touch buttons)?"""
    try: fd = os.open(FW_FB, os.O_RDONLY)
    except OSError: return False
    try:
        # Check rows between 100 and 700 with step 4
        # On a highlighted track row in the library:
        # - x=1040 is inside the white LOAD 1 button
        # - x=1145 is the blue background between LOAD 1 and LOAD 2
        # - x=1160 is inside the white LOAD 2 button
        for y in range(100, 700, 4):
            chunk = os.pread(fd, 484, (y * 1280 + 1040) * 4)   # 121 px: x=1040..1160, BGRX
            if len(chunk) < 484: continue
            if chunk[0] > 200 and chunk[1] > 200 and chunk[2] > 200:
                if chunk[480] > 200 and chunk[481] > 200 and chunk[482] > 200:
                    if chunk[420] > 180 and chunk[421] > 90 and chunk[422] < 40:
                        return True
        return False
    finally: os.close(fd)

load_forwarding = {1: False, 2: False}

# ---- MIDI note -> (key, channel-kind) for deck note channels (0x90/0x91) ----
DECK_NOTES = {0x0B: 'play', 0x0C: 'cue', 0x3F: 'shift', 0x10: 'loopin', 0x11: 'loopout', 0x4D: 'reloop',
              0x58: 'sync', 0x5C: 'master', 0x59: 'master', 0x60: 'temporange', 0x54: 'hpcue', 0x36: 'jogtouch',
              0x67: 'jogtouch',
              0x15: 'vinyl', 0x09: 'trackrev', 0x0A: 'trackfwd', 0x1A: 'mastertempo', 0x14: 'autobeatloop',
              0x1B: 'hotcue', 0x6D: 'autobeatloop', 0x20: 'beatjump', 0x68: 'quantize',
              0x40: 'searchfwd', 0x3D: 'searchfwd', 0x3E: 'searchrev', 0x51: 'callprev', 0x53: 'callnext'}
# SHIFT+PLAY (censor) is added per controller at start-up: 0x0E on the FLX4, 0x47 on the DDJ-400.
# 0x1B hot cue mode, 0x6D beat loop mode, 0x20 beat jump mode select the pad mode on the RX3 too.
MIXER_NOTES = {0x46: ('load', 1), 0x47: ('load', 2), 0x41: ('rotary_press', 0), 0x42: ('back', 0)}
DECK_CC_14 = {0x00: 'tempo'}                       # MSB 0x00 + LSB 0x20 (14-bit)
DECK_CC = {0x04: 'trim', 0x07: 'eqh', 0x0B: 'eqm', 0x0F: 'eql', 0x13: 'fader'}
MASTER_CC = {0x1F: 'cross', 0x0C: 'hpmix', 0x0D: 'hplv', 0x08: 'masterlv'}
JOG_CC = {
    0x01: 'bend', 0x02: 'scratch', 0x06: 'search', 0x07: 'search',  # XDJ-R1
    0x21: 'bend', 0x22: 'scratch', 0x23: 'bend', 0x29: 'search',    # DDJ-FLX4 / DDJ-400
}

msb = {}
deck_playing = {1: False, 2: False}
deck_looping = {1: False, 2: False}
rotary_forwarding = [False]    # browse knob: did the matching press go to the firmware's select key?

# ---- Jog wheel resolution & tracking ----
# Pioneer XDJ-R1 has exactly 600 ticks per 360-degree rotation.
# Native RX3 player expects 6480 optical pulses per rotation (135 frames * 48 pulses/frame = 79380 samples / 12.25).
# Pulse scale: 6480 / 600 = 10.8 pulses per tick.
# 33 1/3 RPM vinyl speed = 600 ticks / 1.8 sec = 333.333 ticks/sec -> speed 1.0.
jog_scale = float(os.environ.get('RX3_JOG_SCALE', '1.0'))
jog_pulse_accum = {1: 0.0, 2: 0.0}
jog_last_time = {1: 0.0, 2: 0.0}
jog_speed = {1: 0.0, 2: 0.0}
jog_active = {1: False, 2: False}
jog_touch_state = {1: False, 2: False}

def jog_stop(deck):
    if jog_active[deck]:
        jog_active[deck] = False
        jog_speed[deck] = 0.0
        extra = int(jog_pulse_accum[deck]) & 0xffff
        send(K['jog'], 4, deck, 0, 0.0, extra)

def jog_watchdog():
    while True:
        time.sleep(0.010)
        now = time.monotonic()
        for d in (1, 2):
            if jog_active[d] and (now - jog_last_time[d]) > 0.040:
                jog_stop(d)

threading.Thread(target=jog_watchdog, daemon=True).start()

# ---- Sound Color FX mapping (XDJ-R1 & FLX4) ----
# RX3 Sound Color FX (SWEEP and NOISE removed as requested):
# 0x50a6 FILTER, 0x50a1 SPACE, 0x50a2 DUB ECHO, 0x50a5 CRUSH
R1_CFX_BUTTONS = (0x4E, 0x4F, 0x50, 0x51)
R1_CFX = {
    0x4E: 0x50a6,  # FILTER button -> FILTER (0x50a6)
    0x50: 0x50a5,  # CRUSH button  -> CRUSH (0x50a5)
    0x4F: 0x50a1,  # PITCH button  -> SPACE (0x50a1)
    0x51: 0x50a2,  # NOISE button  -> DUB ECHO (0x50a2)
}
R1_CFX_KEY_TO_BTN = {v: k for k, v in R1_CFX.items()}
current_cfx = [0x50a6]

def set_r1_cfx(btn):
    base_btn = btn - 0x1C if btn >= 0x6A else btn
    target_key = R1_CFX.get(base_btn)
    if not target_key: return
    if current_cfx[0] == target_key:
        for ch in (1, 2): press(target_key, ch, True)
        time.sleep(0.05)
        for ch in (1, 2): press(target_key, ch, False)
        current_cfx[0] = None
        for b in R1_CFX_BUTTONS: led(0x94, b, False)
    else:
        for ch in (1, 2): press(target_key, ch, True)
        time.sleep(0.05)
        for ch in (1, 2): press(target_key, ch, False)
        current_cfx[0] = target_key
        for b in R1_CFX_BUTTONS: led(0x94, b, b == base_btn)
# ---- Beat FX mapping (XDJ-R1 & FLX4) ----
# RX3 BEAT FX list (key 0x448b):
# 0 DELAY, 1 ECHO, 2 PING PONG, 3 SPIRAL, 4 HELIX, 5 REVERB, 6 FLANGER, 7 PHASER,
# 8 FILTER, 9 TRANS, 10 ROLL, 11 SLIP ROLL, 12 PITCH, 13 VINYL BRAKE
FXCH_MASTER = int(os.environ.get('RX3_FXCH_MASTER', '5'))
beatfx_index = 0
beatfx_on = [False]
beat_knob_last = {}
fxch_last_idx = [-1]
last_fxch = [None]
fxch_list = [0, 1, 2, 3, 4, FXCH_MASTER] # 0:CH1, 1:CH2, 2:MIC, 3:CF.A, 4:CF.B, 5:MASTER

def get_fxch_index(v):
    curr = fxch_last_idx[0]
    if curr == -1:
        idx = min(5, int(v / 21.34))
        fxch_last_idx[0] = idx
        return idx
    while curr < 5 and v >= (curr + 1) * 21.33 + 2:
        curr += 1
    while curr > 0 and v < curr * 21.33 - 2:
        curr -= 1
    fxch_last_idx[0] = curr
    return curr

# ---- Navigation buttons (mapped from XDJ-R1 Beat FX buttons) ----
# Deck 1: TRANS=SOURCE, FLANGER=BROWSE, ECHO=TAG LIST, ROLL=PLAYLIST
# Deck 2: TRANS=SEARCH, FLANGER=MENU
R1_NAV_BUTTONS = {
    (4, 0x46): 'source',
    (4, 0x47): 'browse',
    (4, 0x48): 'taglist',
    (4, 0x49): 'playlist',
    (5, 0x46): 'search',
    (5, 0x47): 'menu',
}
active_r1_nav = ['browse']
shortcut_active = [False]
track_filter_active = [False]

def update_r1_nav_leds():
    if ctl_id != 'xdjr1': return
    for (btn_ch, btn_n), key_name in R1_NAV_BUTTONS.items():
        is_on = (key_name == active_r1_nav[0])
        led(0x90 + btn_ch, btn_n, is_on)

shift_down = {1: False, 2: False}
usb_stop_holding = {1: False, 2: False}

def usb_stop_worker(deck):
    slot = deck
    t_start = time.time()
    firmware_pressed = False
    try:
        while time.time() - t_start < 4.0:
            if not usb_stop_holding[deck]:
                return
            elapsed = time.time() - t_start
            # Fast blinking on BACK button LED (toggle every 0.2s)
            led_state = int(elapsed * 5) % 2 == 0
            led(0x90 + deck - 1, 0x44, led_state)
            led(0x90 + deck - 1, 0x45, led_state)
            if elapsed >= 2.0 and not firmware_pressed:
                firmware_pressed = True
                send(K['usbstop'], 0, slot)
            time.sleep(0.05)

        # 4.0s completed while held down!
        if usb_stop_holding[deck]:
            if not firmware_pressed:
                send(K['usbstop'], 0, slot)
                firmware_pressed = True
            time.sleep(0.2)
            send(K['usbstop'], 2, slot)
            firmware_pressed = False
            # Solid LED for 1.2s to confirm successful unmount
            led(0x90 + deck - 1, 0x44, True)
            led(0x90 + deck - 1, 0x45, True)
            time.sleep(1.2)
    finally:
        if firmware_pressed and not usb_stop_holding[deck]:
            send(K['usbstop'], 2, slot)
        led(0x90 + deck - 1, 0x44, False)
        led(0x90 + deck - 1, 0x45, False)

def note(status, n, vel):
    ch = status & 0x0F; down = (status & 0xF0) == 0x90 and vel > 0
    if ch in (0, 1):
        deck = ch + 1
        if ctl_id == 'xdjr1':
            if n == 0x3F:   # SHIFT + TIME button on XDJ-R1 -> Toggle Quantize on both decks
                for d in (1, 2):
                    press(K['quantize'], d, down)
                return
            if n == 0x3E:   # TIME button (unshifted) -> toggle elapsed/remain time
                press(K['time'], deck, down)
                return
            if n in (0x14, 0x50):   # AUTO BEAT LOOP encoder press
                if down:
                    send(0xFFFC, 0, deck)
                return
            if n == 0x42:   # Rotary selector press on XDJ-R1: enter folder/playlist if folder selected, load if track selected
                if down:
                    if deck_showing():
                        send(K['browse'], 0); send(K['browse'], 2)
                        load_forwarding[deck] = False
                        active_r1_nav[0] = 'browse'
                        update_r1_nav_leds()
                    elif track_selected():
                        load_forwarding[deck] = True
                        press(K['load'], deck, True)
                        deck_looping[deck] = False
                        led(0x90 + deck - 1, 0x14, False)
                        led(0x90 + deck - 1, 0x50, False)
                    else:
                        load_forwarding[deck] = False
                        press(K['rotary'], 0, True)
                else:
                    if load_forwarding.get(deck):
                        press(K['load'], deck, False)
                        load_forwarding[deck] = False
                    else:
                        press(K['rotary'], 0, False)
                return
            if n == 0x43:   # SHIFT + Rotary selector press -> SELECT / rotary push
                press(K['rotary'], 0, down)
                return
            if n in (0x44, 0x45):   # BACK (0x44) or SHIFT+BACK (0x45) on XDJ-R1
                is_shift = (n == 0x45) or shift_down[deck]
                if is_shift:
                    if down:
                        if not usb_stop_holding[deck]:
                            usb_stop_holding[deck] = True
                            threading.Thread(target=usb_stop_worker, args=(deck,), daemon=True).start()
                    else:
                        usb_stop_holding[deck] = False
                    return
                else:
                    if down and shortcut_active[0]:
                        shortcut_active[0] = False
                        led(0x95, 0x49, track_filter_active[0])
                        led(0x95, 0x65, False)
                    press(K['back'], 0, down)
                    return
        name = DECK_NOTES.get(n)
        if name == 'play' and down:
            deck_playing[deck] = not deck_playing[deck]
            led(status, 0x0B, deck_playing[deck])
            led(status, 0x0C, not deck_playing[deck])
        elif name == 'cue' and down:
            deck_playing[deck] = False
            deck_looping[deck] = False
            led(0x90 + deck - 1, 0x14, False)
            led(0x90 + deck - 1, 0x50, False)
            led(status, 0x0B, False)
            led(status, 0x0C, True)
        elif name in ('loopout', 'reloop') and down:
            deck_looping[deck] = False
            led(0x90 + deck - 1, 0x14, False)
            led(0x90 + deck - 1, 0x50, False)
        if name == 'jogtouch':
            jog_touch_state[deck] = down
            if not down: jog_stop(deck)     # the RX3 needs a zero jog report or Play stays blocked after a scratch
            press(K['jogtouch'], deck, down); return
        if name == 'hpcue': press(K['hpcue'], deck, down); return
        if name: press(K[name], deck, down); return
    if ch in (0, 1) and n in PAD_MODES:
        deck = ch + 1
        if not down: return
        pad_mode[deck] = n; show_pad_mode(deck)
        # Forward to the RX3 only when its own pad mode must change. Its HOT CUE key toggles HOT CUE <-> GATE CUE.
        if n == 0x1B:
            if rx3_mode[deck] == 'hotcue': return
            rx3_mode[deck] = 'hotcue'
        elif n == 0x20:
            if rx3_mode[deck] == 'beatjump': return
            rx3_mode[deck] = 'beatjump'
        elif n == 0x6D:
            if rx3_mode[deck] == 'beatloop': return
            rx3_mode[deck] = 'beatloop'
        else: return                        # pad fx / sampler / keyboard / key shift have no RX3 equivalent
    if ch in (0, 1) and n == 0x54 and down: hp_cue[ch + 1] = not hp_cue[ch + 1]; led(status, 0x54, hp_cue[ch + 1])
    if ch in (4, 5):                        # BEAT FX section
        global beatfx_index
        if ctl_id == 'xdjr1':
            if ch == 4:
                base = n - 0x1C if n >= 0x6A else n
                if base in R1_CFX:
                    if down: set_r1_cfx(base)
                    return
            # TAP button on XDJ-R1: Deck A (ch 4) / Deck B (ch 5), notes 0x58 (88), 0x74 (116)
            if n in (0x58, 0x74, 0x59, 0x75):
                press(K['tap'], 0, down)
                led(status, 0x58, down)
                return
            # Navigation buttons (mapped from XDJ-R1 Beat FX buttons)
            # Deck 1: TRANS=SOURCE, FLANGER=BROWSE, ECHO=TAG LIST, ROLL=PLAYLIST
            # Deck 2: TRANS=SEARCH, FLANGER=MENU, ECHO=TAG TRACK/REMOVE, ROLL=TRACK FILTER, SHIFT+ROLL=SHORTCUT
            if ch == 5:
                if n in (0x48, 0x64):   # Deck 2 ECHO -> TAG TRACK / REMOVE
                    press(K['tagtrack'], 0, down)
                    led(0x95, 0x48, down)
                    led(0x95, 0x64, down)
                    return
                if n in (0x49, 0x65):   # Deck 2 ROLL -> TRACK FILTER -EDIT / SHORT CUT
                    is_shift = (n == 0x65) or shift_down[2]
                    if is_shift:
                        press(K['shortcut'], 0, down)
                        if down:
                            shortcut_active[0] = not shortcut_active[0]
                            led(0x95, 0x49, shortcut_active[0])
                            led(0x95, 0x65, shortcut_active[0])
                    else:
                        press(K['trackfilter'], 0, down)
                        if down:
                            track_filter_active[0] = not track_filter_active[0]
                            led(0x95, 0x49, track_filter_active[0])
                            led(0x95, 0x65, track_filter_active[0])
                    return
            base_btn = n - 0x1C if n >= 0x62 else n
            if (ch, base_btn) in R1_NAV_BUTTONS:
                key_name = R1_NAV_BUTTONS[(ch, base_btn)]
                press(K[key_name], 0, down)
                if down:
                    if key_name == 'browse' and active_r1_nav[0] == 'browse':
                        active_r1_nav[0] = None
                    elif key_name == 'menu' and active_r1_nav[0] == 'menu':
                        active_r1_nav[0] = None
                    else:
                        active_r1_nav[0] = key_name
                    update_r1_nav_leds()
                return
            if base_btn in (0x46, 0x47, 0x48, 0x49):
                return
            return
        if n == 0x47: press(K['fxonoff'], 0, down); return
        if n == 0x4A: press(K['beatprev'], 0, down); return
        if n == 0x4B: press(K['beatnext'], 0, down); return
        # RX3 BEAT FX list (switch keys use operation 5 with the value): 0 DELAY 1 ECHO 2 PING PONG 3 SPIRAL 4 HELIX 5 REVERB
        # 6 FLANGER 7 PHASER 8 FILTER 9 TRANS 10 ROLL 11 SLIP ROLL 12 PITCH 13 VINYL BRAKE
        if n == 0x63 and down: beatfx_index = (beatfx_index + 1) % 14; send(K['fxselect'], 5, 0, beatfx_index, float(beatfx_index)); return
        if n == 0x64 and down: beatfx_index = (beatfx_index - 1) % 14; send(K['fxselect'], 5, 0, beatfx_index, float(beatfx_index)); return
        if n in (0x10, 0x11, 0x14) and down:   # CH SELECT slide -> RX3 values: 0 CH1, 1 CH2, 2 MIC, 3 CF.A, 4 CF.B, MASTER = FXCH_MASTER
            sel = CTL['fxch'].get((ch, n), 'master'); sel = FXCH_MASTER if sel == 'master' else sel
            send(K['fxch'], 5, 0, sel, float(sel)); return
        return
    elif ch == 6:
        if ctl_id == 'xdjr1':
            if n in (0x54, 0x55):
                deck = 1 if n == 0x54 else 2
                if down:
                    hp_cue[deck] = not hp_cue[deck]
                    led(0x96, n, hp_cue[deck])
                    send(0xFFFD, 0, deck - 1, 1 if hp_cue[deck] else 0)
                return
            if n in (0x46, 0x66):   # MIC ON/OFF button -> Beat FX ON/OFF
                if down:
                    beatfx_on[0] = not beatfx_on[0]
                    led(0x96, 0x46, beatfx_on[0])
                    press(K['fxonoff'], 0, True)
                else:
                    press(K['fxonoff'], 0, False)
                return
        global cfx_index
        if n == 0x63 and down: cfx_index = (cfx_index + 1) % len(CFX); select_cfx(); return
        m = MIXER_NOTES.get(n)
        if m:
            key, deck = m
            if key == 'rotary_press':
                # Browse knob push: the firmware uses it to select/open on every screen except the deck screen,
                # where it does nothing; there, open the library instead, like the BROWSE key.
                if down:
                    rotary_forwarding[0] = not deck_showing()
                    if rotary_forwarding[0]: press(K['rotary'], 0, True)
                    else: send(K['browse'], 0); send(K['browse'], 2)
                elif rotary_forwarding[0]: press(K['rotary'], 0, False)
            else: press(K[key], deck, down)
            return
    elif ch in (7, 9):                      # performance pads, deck 1 / deck 2
        deck = 1 if ch == 7 else 2
        if n < 0x08 or 0x20 <= n < 0x28 or 0x60 <= n < 0x68:
            press(PAD[n & 7], deck, down); return
    elif ch in (8, 10):                     # shift + pads
        deck = 1 if ch == 8 else 2
        if n < 0x08: press(K['shift'], deck, True); press(PAD[n & 7], deck, down); press(K['shift'], deck, False); return

def cc(status, c, v):
    ch = status & 0x0F
    if ch in (0, 1):
        deck = ch + 1
        if ctl_id == 'xdjr1' and c in (0x13, 0x4F):  # AUTO BEAT LOOP encoder turn
            delta = v if v < 64 else v - 128
            val = 1 if delta > 0 else -1
            count = min(4, abs(delta))
            for _ in range(count):
                send(0xFFFB, 0, deck, val)
                time.sleep(0.01)
            return
        if ctl_id == 'xdjr1' and c == 0x40:
            delta = v if v < 64 else v - 128
            send(K['rotary'], 4, 0, delta, 0.0); return
        if c in DECK_CC_14: msb[(ch, c)] = v; return
        if c in (0x20,):                    # tempo LSB
            m = msb.get((ch, 0x00), 0); val = (m << 7 | v) / 16383.0
            send(K['tempo'], 5, deck, 0, (val - 0.5) * 2.0); return   # op 5 only
        if c in DECK_CC: analog(K[DECK_CC[c]], deck, v / 127.0); return
        if c in (0x24, 0x27, 0x2B, 0x2F, 0x33): return   # LSB echoes of the knobs, ignore
        if c in JOG_CC:
            delta = v - 64                  # relative ticks centered at 64
            if delta == 0:
                return
            kind = JOG_CC[c]
            now = time.monotonic()
            last_t = jog_last_time[deck]
            jog_last_time[deck] = now
            jog_active[deck] = True

            dt = now - last_t if last_t > 0 else 0.025
            if dt > 0.080:
                dt = 0.025
            elif dt < 0.003:
                dt = 0.003

            # Fast search mode (SHIFT + jog)
            if kind == 'search' or c == 0x29:
                delta *= 8

            # Update 16-bit cumulative pulse (10.8 pulses per tick -> 6480 pulses per 360 deg)
            jog_pulse_accum[deck] += delta * (10.8 * jog_scale)
            extra = int(jog_pulse_accum[deck]) & 0xffff

            # Ticks per second, clamped to physical limits
            inst_rate = delta / dt
            if inst_rate > 3000.0: inst_rate = 3000.0
            elif inst_rate < -3000.0: inst_rate = -3000.0

            is_scratch = jog_touch_state[deck] or (kind == 'scratch')

            if is_scratch and jog_touch_state[deck]:
                # Scratch velocity: 333.333 ticks/sec = 1.0x vinyl playback speed
                inst_speed = (inst_rate / 333.333) * jog_scale
                prev_s = jog_speed[deck]
                # Instant response on direction reversal or startup; light smoothing in steady direction
                if delta * prev_s <= 0:
                    speed = inst_speed
                else:
                    speed = 0.70 * inst_speed + 0.30 * prev_s
                # Clamp to firmware limits [-8.0, +8.0]
                if speed > 8.0: speed = 8.0
                elif speed < -8.0: speed = -8.0
                if abs(speed) < 0.04: speed = 0.0
                jog_speed[deck] = speed
                analog_val = speed
            else:
                # Pitch bend / nudge velocity:
                # Firmware Player::controlPitchbend subtracts 0.5 from abs(analog) and multiplies by 0.08:
                # pitchbend = (abs(analog) - 0.5) * 0.08 * sign
                # So analog must be sign * (0.5 + v_bend) to overcome the 0.5 deadband.
                sign = 1.0 if delta > 0 else -1.0
                # 100 ticks/sec gives v_bend = 0.5 -> 4% pitch bend (medium nudge)
                v_bend = (abs(inst_rate) / 200.0) * jog_scale
                if v_bend < 0.02: v_bend = 0.02
                if v_bend > 2.0: v_bend = 2.0
                analog_val = sign * (0.5 + v_bend)
                jog_speed[deck] = analog_val

            send(K['jog'], 4, deck, delta, analog_val, extra)
            return
    elif ch in (4, 5):
        global beatfx_index
        if ctl_id == 'xdjr1':
            if c == 0x10:       # SHIFT + BEAT encoder -> select Beat FX (relative 2's complement: 0x01 / 0x7F)
                delta = v if v < 64 else v - 128
                beatfx_index = (beatfx_index + delta) % 14
                send(K['fxselect'], 5, 0, beatfx_index, float(beatfx_index))
                return
            elif c == 0x00:     # BEAT encoder without SHIFT -> BEAT fraction (BeatPrev / BeatNext)
                last = beat_knob_last.get(ch)
                beat_knob_last[ch] = v
                if last is None:
                    return
                if v == last:
                    if v >= 126: d = 1
                    elif v <= 1: d = -1
                    else: d = 0
                else:
                    d = v - last
                    if d > 64: d -= 128
                    elif d < -64: d += 128
                if d == 0:
                    return
                key = K['beatnext'] if d > 0 else K['beatprev']
                count = min(3, abs(d))
                for _ in range(count):
                    press(key, 0, True)
                    time.sleep(0.01)
                    press(key, 0, False)
                return
        if c == 0x02: msb[(ch, 2)] = v; return
        if c == 0x22: analog(K['fxdepth'], 0, (msb.get((ch, 2), 0) << 7 | v) / 16383.0); return
    elif ch == 6:
        if ctl_id == 'xdjr1':
            if c == 0x14:           # MIC LEVEL knob -> Beat FX Channel Select
                idx = get_fxch_index(v)
                sel = fxch_list[idx]
                if sel != last_fxch[0]:
                    last_fxch[0] = sel
                    send(K['fxch'], 5, 0, sel, float(sel))
                return
            if c == 0x34: return    # MIC LEVEL knob LSB
            if c == 0x00: analog(K['masterlv'], 0, v / 127.0); return
            if c == 0x02: analog(K['hplv'], 0, v / 127.0); return
            if c == 0x01: analog(K['hpmix'], 0, v / 127.0); return
            if c == 0x13: analog(K['fader'], 1, v / 127.0); return
            if c == 0x15: analog(K['fader'], 2, v / 127.0); return
            if c == 0x1F: analog(K['cross'], 0, v / 127.0); return
            if c == 0x03: analog(K['trim'], 1, v / 127.0); return
            if c == 0x04: analog(K['trim'], 2, v / 127.0); return
            if c == 0x07: analog(K['eqh'], 1, v / 127.0); return
            if c == 0x08: analog(K['eqh'], 2, v / 127.0); return
            if c == 0x0B: analog(K['eqm'], 1, v / 127.0); return
            if c == 0x0C: analog(K['eqm'], 2, v / 127.0); return
            if c == 0x0F: analog(K['eql'], 1, v / 127.0); return
            if c == 0x10: analog(K['eql'], 2, v / 127.0); return
            if c == 0x1B: analog(K['color'], 1, v / 127.0); return
            if c == 0x1C: analog(K['color'], 2, v / 127.0); return
            if c in (0x20, 0x21, 0x22, 0x23, 0x24, 0x27, 0x28, 0x2B, 0x2C, 0x2F, 0x30, 0x33, 0x35, 0x37, 0x38, 0x3B, 0x3C, 0x3F): return
        else:
            if c == 0x17: analog(K['color'], 1, v / 127.0); return
            if c == 0x18: analog(K['color'], 2, v / 127.0); return
            if c in (0x37, 0x38): return
            if c == 0x40: send(K['rotary'], 4, 0, v if v < 64 else v - 128, 0.0); return   # relative encoder: 1..63 cw, 127..65 ccw
            if c in MASTER_CC: analog(K[MASTER_CC[c]], 0, v / 127.0); return

found = controllers.detect()
forced = os.environ.get('RX3_CONTROLLER')
if forced:
    ctl_id = forced
elif found:
    ctl_id = found[0][1]
    if len(found) > 1: print('controller-bridge: %d controllers connected, using the first plugged in (%s)' % (len(found), controllers.CONTROLLERS[ctl_id]['name']), flush=True)
else:
    print('controller-bridge: no known DJ controller connected (%s)' % ', '.join(c['name'] for c in controllers.CONTROLLERS.values()), file=sys.stderr); sys.exit(1)
CTL = controllers.CONTROLLERS[ctl_id]
dev = sys.argv[1] if len(sys.argv) > 1 else (controllers.midi_device(found[0][0]) if found else None)
if not dev: print('controller-bridge: %s has no MIDI device' % CTL['name'], file=sys.stderr); sys.exit(1)
print('controller-bridge: %s on %s' % (CTL['name'], dev), flush=True)
DECK_NOTES[CTL['censor']] = 'slip'          # SHIFT+PLAY (censor) drives the RX3's SLIP; the note differs per controller

import threading
try: midi_out = os.open(dev if dev != '-' else os.environ.get('RX3_MIDI_OUT', '/dev/null'), os.O_WRONLY | (0 if dev != '-' else os.O_CREAT | os.O_APPEND), 0o644)   # keep-alive, init, LEDs
except OSError as e: print('controller-bridge: cannot open MIDI out:', e, file=sys.stderr, flush=True); sys.exit(3)
out_lock = threading.Lock()
def midi_write(b):
    with out_lock:
        try: os.write(midi_out, b)
        except OSError as e: print('controller-bridge: MIDI out failed:', e, file=sys.stderr, flush=True); os._exit(3)
if CTL['init']: midi_write(CTL['init'])
if CTL['keepalive']:
    def keepalive():
        while True: midi_write(CTL['keepalive']); time.sleep(CTL['keepalive_period'])
    threading.Thread(target=keepalive, daemon=True).start()

# ---- LED feedback (the firmware's own panel LEDs are not available to us yet, so we mirror what we know locally) ----
def led(status, note, on):
    midi_write(bytes([status, note, 0x7F if on else 0x00]))
    if LOG: print('%s led %02x %02x %s' % (time.strftime('%H:%M:%S'), status, note, 'on' if on else 'off'), flush=True)
PAD_MODES = [0x1B, 0x6D, 0x20, 0x22, 0x1E, 0x69, 0x6F]      # hot cue, beat loop, beat jump, sampler, pad fx1, keyboard, key shift
pad_mode = {1: 0x1B, 2: 0x1B}
rx3_mode = {1: 'hotcue', 2: 'hotcue'}          # what the firmware is in (hotcue / beatjump / beatloop)
hp_cue = {1: True, 2: False}                                 # control-shim.c enables deck 1 cue at startup
def show_pad_mode(deck):
    for n in PAD_MODES: led(0x90 + deck - 1, n, n == pad_mode[deck])
def init_leds():
    time.sleep(1.0)
    send(0xFFFE, 0, 0, 1)  # Ensure Master Cue is enabled in headphone mix
    send(0xFFF9, 0, 0, 1)  # Ensure Preview Cue (Link Cue) is enabled in headphone mix
    if ctl_id == 'xdjr1':
        send(0xFFFD, 0, 0, 1 if hp_cue[1] else 0)
        send(0xFFFD, 0, 1, 1 if hp_cue[2] else 0)
        led(0x96, 0x54, hp_cue[1])
        led(0x96, 0x55, hp_cue[2])
        led(0x96, 0x46, beatfx_on[0])
        led(0x94, 0x58, False)
        led(0x95, 0x58, False)
        update_r1_nav_leds()
        led(0x95, 0x48, False)
        led(0x95, 0x49, False)
        led(0x95, 0x64, False)
        led(0x95, 0x65, False)
        for d in (1, 2):
            led(0x90 + d - 1, 0x0B, False)
            led(0x90 + d - 1, 0x0C, True)
            led(0x90 + d - 1, 0x14, False)
            led(0x90 + d - 1, 0x37, True)
    else:
        for d in (1, 2): show_pad_mode(d); led(0x90 + d - 1, 0x54, hp_cue[d])
threading.Thread(target=init_leds, daemon=True).start()

LOOP_STATE_FILE = ROOT + '/dev/rx3-loop-state'
R1_BEAT_LEDS = [0x75, 0x74, 0x73, 0x72, 0x71, 0x70, 0x6F, 0x6E]  # 1/4, 1/2, 1, 2, 4, 8, 16, 32

def loop_led_monitor():
    last_state = None
    while True:
        try:
            with open(LOOP_STATE_FILE, 'rb') as f:
                data = f.read(4)
            if len(data) >= 4 and data != last_state:
                last_state = data
                for d in (1, 2):
                    is_looping = bool(data[d - 1])
                    loop_idx = data[1 + d]
                    deck_looping[d] = is_looping
                    led(0x90 + d - 1, 0x14, is_looping)
                    led(0x90 + d - 1, 0x50, is_looping)
                    if ctl_id == 'xdjr1':
                        for i, note_id in enumerate(R1_BEAT_LEDS):
                            led(0x90 + d - 1, note_id, (i == loop_idx and is_looping))
        except Exception:
            pass
        time.sleep(0.04)

threading.Thread(target=loop_led_monitor, daemon=True).start()

# ---- Sound Color FX: the RX3 needs an effect selected before the per-channel COLOR knobs do anything ----
# Engine effect slots (SoundColorFxManager ctor order = type number): 1 FILTER, 4 DUB ECHO, 5 SPACE, 6 CRUSH.
# Keys: 0x50a6 filter, 0x50a1 space, 0x50a2 dub echo, 0x50a5 crush. (SWEEP 0x50a3 and NOISE 0x50a4 removed).
# Pressing the active effect's key again switches it off. Start on FILTER.
CFX = [0x50a6, 0x50a1, 0x50a2, 0x50a5]
cfx_index = 0
def select_cfx():
    for ch in (1, 2):                       # effect type is per mixer channel; the key must carry the channel
        press(CFX[cfx_index], ch, True); time.sleep(0.05); press(CFX[cfx_index], ch, False)
    current_cfx[0] = CFX[cfx_index]
threading.Timer(2.0, select_cfx).start()

def cfx_blink_worker():
    blink_state = False
    last_active = None
    while True:
        try:
            active_key = current_cfx[0]
            if ctl_id == 'xdjr1':
                if active_key != last_active:
                    last_active = active_key
                    blink_state = True
                    if active_key is None:
                        for b in R1_CFX_BUTTONS: led(0x94, b, False)
                    else:
                        active_btn = R1_CFX_KEY_TO_BTN.get(active_key)
                        for b in R1_CFX_BUTTONS:
                            led(0x94, b, b == active_btn)
                elif active_key is not None:
                    blink_state = not blink_state
                    active_btn = R1_CFX_KEY_TO_BTN.get(active_key)
                    if active_btn:
                        led(0x94, active_btn, blink_state)
        except Exception:
            pass
        time.sleep(0.25)

threading.Thread(target=cfx_blink_worker, daemon=True).start()

buf = b''
with open(dev if dev != '-' else 0, 'rb', buffering=0) as f:
    while True:
        try: data = f.read(64)
        except OSError as e: print('controller-bridge: MIDI in failed:', e, file=sys.stderr, flush=True); sys.exit(3)
        if not data: time.sleep(.01); continue
        buf += data
        while buf:
            s = buf[0]
            if s < 0x80: buf = buf[1:]; continue          # skip stray data bytes
            if s >= 0xF0: buf = buf[1:]; continue          # ignore system messages
            if len(buf) < 3: break
            d1, d2 = buf[1], buf[2]; buf = buf[3:]
            kind = s & 0xF0
            if LOG: print('%s midi %02x %02x %02x' % (time.strftime('%H:%M:%S'), s, d1, d2), flush=True)
            if kind in (0x80, 0x90): note(s, d1, d2)
            elif kind == 0xB0: cc(s, d1, d2)
